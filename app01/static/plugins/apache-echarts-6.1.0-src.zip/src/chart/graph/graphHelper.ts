/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

import GraphSeriesModel from './GraphSeries';
import { calcCompensationScaleToPreserveNodeSize, isViewCoordSys } from '../../coord/View';
import { GraphNode } from '../../data/Graph';

export function getNodeGlobalScale(seriesModel: GraphSeriesModel) {
    const coordSys = seriesModel.coordinateSystem;
    return isViewCoordSys(coordSys)
        ? calcCompensationScaleToPreserveNodeSize(coordSys, seriesModel)
        // Geo coord sys do not use `Transformable`.
        // PENDING: historially `nodeScaleRatio` has not been applied on
        // geo based graph series.
        : 1;
}

export function getSymbolSize(node: GraphNode) {
    let symbolSize = node.getVisual('symbolSize');
    if (symbolSize instanceof Array) {
        symbolSize = (symbolSize[0] + symbolSize[1]) / 2;
    }
    return +symbolSize;
}

