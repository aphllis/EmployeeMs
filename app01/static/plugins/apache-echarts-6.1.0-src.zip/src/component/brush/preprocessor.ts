/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


import * as zrUtil from 'zrender/src/core/util';
import { ECUnitOption } from '../../util/types';
import { BrushOption, BrushToolboxIconType } from './BrushModel';
import { ToolboxOption } from '../toolbox/ToolboxModel';
import { ToolboxBrushFeatureOption } from '../toolbox/feature/Brush';
import { normalizeToArray, removeDuplicates } from '../../util/model';

const DEFAULT_TOOLBOX_BTNS: BrushToolboxIconType[] = ['rect', 'polygon', 'keep', 'clear'];

export default function brushPreprocessor(option: ECUnitOption, isNew: boolean): void {
    const brushComponents = normalizeToArray(option ? option.brush : []);

    if (!brushComponents.length) {
        return;
    }

    let brushComponentSpecifiedBtns = [] as string[];

    zrUtil.each(brushComponents, function (brushOpt: BrushOption) {
        const tbs = brushOpt.hasOwnProperty('toolbox')
            ? brushOpt.toolbox : [];

        if (tbs instanceof Array) {
            brushComponentSpecifiedBtns = brushComponentSpecifiedBtns.concat(tbs);
        }
    });

    let toolbox: ToolboxOption = option && option.toolbox;

    if (zrUtil.isArray(toolbox)) {
        toolbox = toolbox[0];
    }
    if (!toolbox) {
        toolbox = {feature: {}};
        option.toolbox = [toolbox];
    }

    const toolboxFeature = (toolbox.feature || (toolbox.feature = {}));
    const toolboxBrush = (toolboxFeature.brush || (toolboxFeature.brush = {})) as ToolboxBrushFeatureOption;
    const brushTypes = toolboxBrush.type || (toolboxBrush.type = []);

    brushTypes.push.apply(brushTypes, brushComponentSpecifiedBtns);

    removeDuplicates(brushTypes, item => item + '', null);

    if (isNew && !brushTypes.length) {
        brushTypes.push.apply(brushTypes, DEFAULT_TOOLBOX_BTNS);
    }
}
