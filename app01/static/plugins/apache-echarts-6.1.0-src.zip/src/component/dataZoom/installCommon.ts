/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

import { EChartsExtensionInstallRegisters } from '../../extension';
import dataZoomProcessor from './dataZoomProcessor';
import installDataZoomAction from './dataZoomAction';
import { makeCallOnlyOnce } from '../../util/model';

const callOnlyOnce = makeCallOnlyOnce();

export default function installCommon(registers: EChartsExtensionInstallRegisters) {

    callOnlyOnce(registers, function () {
        registers.registerProcessor(registers.PRIORITY.PROCESSOR.FILTER, dataZoomProcessor);

        installDataZoomAction(registers);

        registers.registerSubTypeDefaulter('dataZoom', function () {
            // Default 'slider' when no type specified.
            return 'slider';
        });
    });
}