/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


import * as zrUtil from 'zrender/src/core/util';
import Polar, { polarDimensions } from './Polar';
import {parsePercent} from '../../util/number';
import {
    createScaleByModel,
    determineAxisType,
    isAxisOnBand,
} from '../../coord/axisHelper';

import PolarModel, { COMPONENT_TYPE_POLAR, COORD_SYS_TYPE_POLAR } from './PolarModel';
import ExtensionAPI from '../../core/ExtensionAPI';
import GlobalModel from '../../model/Global';
import OrdinalScale from '../../scale/Ordinal';
import RadiusAxis from './RadiusAxis';
import AngleAxis from './AngleAxis';
import { PolarAxisModel, AngleAxisModel, RadiusAxisModel } from './AxisModel';
import SeriesModel from '../../model/Series';
import { SeriesOption } from '../../util/types';
import { SINGLE_REFERRING } from '../../util/model';
import { createBoxLayoutReference } from '../../util/layout';
import { scaleCalcNice } from '../axisNiceTicks';
import {
    AXIS_EXTENT_INFO_BUILD_FROM_COORD_SYS_UPDATE, scaleRawExtentInfoCreate
} from '../scaleRawExtentInfo';
import { associateSeriesWithAxis } from '../axisStatistics';

/**
 * Resize method bound to the polar
 */
function resizePolar(polar: Polar, polarModel: PolarModel, api: ExtensionAPI) {
    const center = polarModel.get('center');

    const refContainer = createBoxLayoutReference(polarModel, api).refContainer;

    polar.cx = parsePercent(center[0], refContainer.width) + refContainer.x;
    polar.cy = parsePercent(center[1], refContainer.height) + refContainer.y;

    const radiusAxis = polar.getRadiusAxis();
    const size = Math.min(refContainer.width, refContainer.height) / 2;

    let radius = polarModel.get('radius');
    if (radius == null) {
        radius = [0, '100%'];
    }
    else if (!zrUtil.isArray(radius)) {
        // r0 = 0
        radius = [0, radius];
    }
    const parsedRadius = [
        parsePercent(radius[0], size),
        parsePercent(radius[1], size)
    ];

    radiusAxis.inverse
        ? radiusAxis.setExtent(parsedRadius[1], parsedRadius[0])
        : radiusAxis.setExtent(parsedRadius[0], parsedRadius[1]);
}

/**
 * Update polar
 */
function updatePolarScale(this: Polar, ecModel: GlobalModel, api: ExtensionAPI) {
    const polar = this;
    const angleAxis = polar.getAngleAxis();
    const radiusAxis = polar.getRadiusAxis();

    scaleRawExtentInfoCreate(angleAxis, AXIS_EXTENT_INFO_BUILD_FROM_COORD_SYS_UPDATE);
    scaleRawExtentInfoCreate(radiusAxis, AXIS_EXTENT_INFO_BUILD_FROM_COORD_SYS_UPDATE);

    scaleCalcNice(angleAxis);
    scaleCalcNice(radiusAxis);

    // Fix extent of category angle axis
    if (angleAxis.type === 'category' && !angleAxis.onBand) {
        const extent = angleAxis.getExtent();
        const diff = 360 / (angleAxis.scale as OrdinalScale).count();
        angleAxis.inverse ? (extent[1] += diff) : (extent[1] -= diff);
        angleAxis.setExtent(extent[0], extent[1]);
    }
}

function isAngleAxisModel(axisModel: AngleAxisModel | PolarAxisModel): axisModel is AngleAxisModel {
    return axisModel.mainType === 'angleAxis';
}
/**
 * Set common axis properties
 */
function setAxis(axis: RadiusAxis | AngleAxis, axisModel: PolarAxisModel) {
    axis.type = determineAxisType(axisModel);
    axis.scale = createScaleByModel(axisModel, axis.type, false);
    axis.onBand = isAxisOnBand(axis.scale, axisModel);
    axis.inverse = axisModel.get('inverse');

    if (isAngleAxisModel(axisModel)) {
        axis.inverse = axis.inverse !== axisModel.get('clockwise');
        const startAngle = axisModel.get('startAngle');
        const endAngle = axisModel.get('endAngle') ?? (startAngle + (axis.inverse ? -360 : 360));
        axis.setExtent(startAngle, endAngle);
    }

    // Inject axis instance
    axisModel.axis = axis;
    axis.model = axisModel as AngleAxisModel | RadiusAxisModel;
}

const polarCreator = {

    dimensions: polarDimensions,

    create: function (ecModel: GlobalModel, api: ExtensionAPI) {
        const polarList: Polar[] = [];
        ecModel.eachComponent(COMPONENT_TYPE_POLAR, function (polarModel: PolarModel, idx: number) {
            const polar = new Polar(idx + '');
            // Inject resize and update method
            polar.update = updatePolarScale;

            const radiusAxis = polar.getRadiusAxis();
            const angleAxis = polar.getAngleAxis();

            const radiusAxisModel = polarModel.findAxisModel('radiusAxis');
            const angleAxisModel = polarModel.findAxisModel('angleAxis');

            setAxis(radiusAxis, radiusAxisModel);
            setAxis(angleAxis, angleAxisModel);

            resizePolar(polar, polarModel, api);

            polarList.push(polar);

            polarModel.coordinateSystem = polar;
            polar.model = polarModel;
        });
        // Inject coordinateSystem to series
        ecModel.eachSeries(function (seriesModel: SeriesModel<SeriesOption & {
            polarIndex?: number
            polarId?: string
        }>) {
            if (seriesModel.get('coordinateSystem') === COORD_SYS_TYPE_POLAR) {
                const polarModel = seriesModel.getReferringComponents(
                    COMPONENT_TYPE_POLAR, SINGLE_REFERRING
                ).models[0] as PolarModel;

                if (__DEV__) {
                    if (!polarModel) {
                        throw new Error(
                            'Polar "' + zrUtil.retrieve<number | string>(
                                seriesModel.get('polarIndex'),
                                seriesModel.get('polarId'),
                                0
                            ) + '" not found'
                        );
                    }
                }
                const polar = seriesModel.coordinateSystem = polarModel.coordinateSystem;
                if (polar) {
                    associateSeriesWithAxis(polar.getRadiusAxis(), seriesModel, COORD_SYS_TYPE_POLAR);
                    associateSeriesWithAxis(polar.getAngleAxis(), seriesModel, COORD_SYS_TYPE_POLAR);
                }
            }
        });

        return polarList;
    }
};

export default polarCreator;